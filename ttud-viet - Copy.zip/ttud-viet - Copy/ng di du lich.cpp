#include <iostream>
#include <vector>
#include <climits>
using namespace std;

const int INF = 1e9;
int n;
vector<vector<int>> cost;
vector<vector<int>> dp;

int tsp(int mask, int u) {
    if (mask == (1 << n) - 1)
        return cost[u][0]; // quay v? th�nh ph? xu?t ph�t

    if (dp[mask][u] != -1)
        return dp[mask][u];

    int ans = INF;
    for (int v = 0; v < n; ++v) {
        if (!(mask & (1 << v))) { // n?u ch�a �i qua th�nh ph? v
            ans = min(ans, cost[u][v] + tsp(mask | (1 << v), v));
        }
    }

    return dp[mask][u] = ans;
}

int main() {
    cout << "Nhap so thanh pho: ";
    cin >> n;

    cost.assign(n, vector<int>(n));
    cout << "Nhap ma tran chi phi (" << n << "x" << n << "):\n";
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            cin >> cost[i][j];

    dp.assign(1 << n, vector<int>(n, -1));

    int result = tsp(1, 0); // b?t �?u t? th�nh ph? 0, �? �i qua 0 (mask = 1)
    cout << "Chi phi nho nhat la: " << result << endl;

    return 0;
}

