#include <bits/stdc++.h>
using namespace std;

char a[1001][1001];
int b[1001][1001]={0};
int main(){
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cin>>a[i][j];
            if(i==1 && j==1 ){
                b[i][j]=1;
            }
            else
            if(a[i][j]=='.')
                b[i][j]=b[i-1][j]+b[i][j-1];
        }
    }

    cout<<b[n][n];
    return 0;
}