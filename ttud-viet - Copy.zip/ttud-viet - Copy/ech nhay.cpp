#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,k;
    cin>>n>>k;
    int a[n],b[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
        b[i]=INT_MAX;
    }
    b[0]=0;
    for(int i=1;i<n;i++){
        for(int j=i-1;j>=i-k;j--)
        if(j>=0){
            b[i]=min(b[i],b[j]+abs(a[i]-a[j]));
        }
    }
    cout<<b[n-1];
    return 0;
}