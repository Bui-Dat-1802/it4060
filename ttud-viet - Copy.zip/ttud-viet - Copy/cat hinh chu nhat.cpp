#include <iostream>
#include <vector>
using namespace std;

int H, W, n;
vector<pair<int, int>> rects;
bool used[10][10];

bool canPlace(int x, int y, int h, int w) {
    if (x + h > H || y + w > W) return false;
    for (int i = x; i < x + h; ++i)
        for (int j = y; j < y + w; ++j)
            if (used[i][j]) return false;
    return true;
}

void place(int x, int y, int h, int w, bool value) {
    for (int i = x; i < x + h; ++i)
        for (int j = y; j < y + w; ++j)
            used[i][j] = value;
}

bool backtrack(int index) {
    if (index == n) return true;
    int h = rects[index].first, w = rects[index].second;
    for (int i = 0; i <= H - h; ++i) {
        for (int j = 0; j <= W - w; ++j) {
            if (canPlace(i, j, h, w)) {
                place(i, j, h, w, true);
                if (backtrack(index + 1)) return true;
                place(i, j, h, w, false);  // backtrack
            }
        }
    }
    return false;
}

int main() {
    cin >> H >> W;
    cin >> n;
    rects.resize(n);
    for (int i = 0; i < n; ++i) {
        cin >> rects[i].first >> rects[i].second;
    }

    if (backtrack(0)) cout << "1\n";
    else cout << "0\n";

    return 0;
}

