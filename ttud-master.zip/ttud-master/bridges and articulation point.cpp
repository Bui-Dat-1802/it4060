//C++ diem khop va cau noi trong do thi 
#include <bits/stdc++.h> 
using namespace std;

const int MAX = 100005;
vector<int> adj[MAX];
bool visited[MAX];
int num[MAX], low[MAX];
int timer = 0;
bool isArticulation[MAX];
vector<pair<int, int>> bridges;

void dfs(int u, int parent) {
    visited[u] = true;
    num[u] = low[u] = ++timer;
    int children = 0;
    for (int v : adj[u]) {
        if (v == parent) continue;
        if (visited[v]) {
            low[u] = min(low[u], num[v]);
        } else {
            dfs(v, u);
            low[u] = min(low[u], low[v]);
            if (low[v] > num[u]) {
                bridges.push_back({min(u, v), max(u, v)});
            }
            if (parent != -1 && low[v] >= num[u]) {
                isArticulation[u] = true;
            }
            ++children;
        }
    }
    if (parent == -1 && children > 1) {
        isArticulation[u] = true;
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u); 
    }
    for (int i = 1; i <= n; ++i) {
        visited[i] = false;
        isArticulation[i] = false;
    }
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i, -1);
        }
    }
    int articulationCount = 0;
    for (int i = 1; i <= n; ++i) {
        if (isArticulation[i]) ++articulationCount;
    }
    int bridgeCount = bridges.size();
    cout << articulationCount << " " << bridgeCount << endl;
    return 0;
}

