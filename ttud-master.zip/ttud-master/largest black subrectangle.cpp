//C++ dien tich hcn to mau max  
#include <bits/stdc++.h>
using namespace std;

int largestRectangle(vector<vector<int>>& A, int n, int m) {
    vector<vector<int>> dp(n, vector<int>(m, 0));
    int maxArea = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (A[i][j] == 1)
                dp[i][j] = (j == 0) ? 1 : dp[i][j - 1] + 1;
        }
    }
    for (int j = 0; j < m; j++) {
        for (int i = 0; i < n; i++) {
            int width = dp[i][j], height = 0;
            for (int k = i; k >= 0 && dp[k][j] > 0; k--) {
                width = min(width, dp[k][j]);  
                height++;
                maxArea = max(maxArea, width * height);
            }
        }
    }
    return maxArea;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> A(n, vector<int>(m));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            cin >> A[i][j];

    cout << largestRectangle(A, n, m) << endl;
    return 0;
}

