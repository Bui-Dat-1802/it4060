//C++ 
#include <bits/stdc++.h> 
using namespace std;

const int MAX = 1000001;
const int MOD = 1000000007;

vector<int> bit(MAX, 0);
void update(int x) {
    for (; x < MAX; x += x & -x)
        bit[x]++;
}
int query(int x) {
    int res = 0;
    for (; x > 0; x -= x & -x)
        res += bit[x];
    return res;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    vector<int> a(n);
    for (int &x : a) cin >> x;
    long long inv = 0;
    for (int i = n - 1; i >= 0; --i) {
        inv = (inv + query(a[i] - 1)) % MOD;
        update(a[i]);
    }

    cout << inv << '\n';
    return 0;
}
// dem d�y so dao nguoc  
