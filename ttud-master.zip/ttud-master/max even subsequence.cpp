//C++ day con chan lon nhat  
#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin >> n;
    long long minEven = 0;                
    long long minOdd  = LLONG_MAX;        
    long long prefix = 0;                 
    long long ans    = LLONG_MIN;        
    for(int i = 0; i < n; ++i){
        long long x;
        cin >> x;
        prefix += x;
        if ((prefix & 1) == 0) {
            ans = max(ans, prefix - minEven);
            minEven = min(minEven, prefix);
        } else {
            if (minOdd != LLONG_MAX)
                ans = max(ans, prefix - minOdd);
            minOdd = min(minOdd, prefix);
        }
    }
    if (ans == LLONG_MIN) 
        cout << "NOT_FOUND\n";
    else 
        cout << ans << "\n";
    return 0;
}

