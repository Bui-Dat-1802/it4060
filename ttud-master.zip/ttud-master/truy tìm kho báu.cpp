//C++ duong di toi uu qua kho bau de duoc luong vang max 
#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n; 
    cin >> n;
    struct T{ll x,y,c;} a[n];
    for(int i=0;i<n;i++) cin>>a[i].x>>a[i].y>>a[i].c;
    sort(a, a+n, [](auto &A, auto &B){
        return A.x!=B.x ? A.x<B.x : A.y<B.y;
    });
    vector<ll> dp(n);
    ll ans = 0;
    for(int i=0;i<n;i++){
        dp[i] = a[i].c;
        for(int j=0;j<i;j++){
            if(a[j].y <= a[i].y)
                dp[i] = max(dp[i], dp[j] + a[i].c);
        }
        ans = max(ans, dp[i]);
    }
    cout << ans << "\n";
    return 0;
}

