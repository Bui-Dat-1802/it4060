//C++ day con khoang cach toi da  
#include <bits/stdc++.h> 
using namespace std;

bool canPlace(const vector<int>& positions, int C, int dist) {
    int count = 1; 
    int last = positions[0];
    for (int i = 1; i < positions.size(); i++) {
        if (positions[i] - last >= dist) {
            count++;
            last = positions[i];
            if (count == C) return true;
        }
    }
    return false;
}

int solve(int N, int C, vector<int>& positions) {
    sort(positions.begin(), positions.end());
    int low = 1, high = positions[N - 1] - positions[0];
    int result = 0;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (canPlace(positions, C, mid)) {
            result = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    return result;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int T;
    cin >> T;
    while (T--) {
        int N, C;
        cin >> N >> C;
        vector<int> positions(N);
        for (int i = 0; i < N; i++) {
            cin >> positions[i];
        }
        cout << solve(N, C, positions) << '\n';
    }
    return 0;
}

