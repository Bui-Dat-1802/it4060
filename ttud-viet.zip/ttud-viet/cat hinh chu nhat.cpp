/*
 * Given a material having the shape rectangle with height H and width W.
 * We need to cut this material into n smaller rectangle submaterials of size (h1,w1), (h2, w2), ..., (hn, wn).
 * Write a program to check if we can perform this cut.
 *   Input
 * Line 1: contains two positive integers H, W (1 <= H, W <= 10)
 * Line 2: contains a positive integer n (1 <= n <= 10)
 * Line i+2 (i= 1,...,n): contains two positive integer hi and wi (1 <= hi, wi <= 10)
 */

// #include <bits/stdc++.h>
// using namespace std;

// const int N = 1000;

// long long fibo[N + 1] = {0};

// long long fib1(int n)
// {
//     long long a = 0, b = 1;
//     if (n <= 1)
//         return 1;
//     for (int i = 2; i <= n; i++)
//     {
//         int c = a + b;
//         a = b;
//         b = c;
//     }
//     return b;
// }

// long long fib(int n)
// {
//     if (n <= 1)
//         return n;
//     if (fibo[n] != 0)
//         return fibo[n];
//     return fibo[n] = fib(n - 1) + fib(n - 2);
// }

// int main()
// {
//     int n;
//     cin >> n;
//     cout << fib(n) << endl;
//     cout << fib1(n) << endl;
//     return 0;
// }

#include <bits/stdc++.h>

using namespace std;

int n, H, W, h[20], w[20], dd[20][20];

bool can_fit(int x, int y, int h, int w)
{
    for (int i = x; i <= x + h - 1; i++)
    {
        for (int j = y; j <= y + w - 1; j++)
        {
            if (dd[i][j])
                return false;
        }
    }
    return true;
}

void place(int x, int y, int h, int w)
{
    for (int i = x; i <= x + h - 1; i++)
    {
        for (int j = y; j <= y + w - 1; j++)
        {
            dd[i][j] = 1;
        }
    }
}

void remov(int x, int y, int h, int w)
{
    for (int i = x; i <= x + h - 1; i++)
    {
        for (int j = y; j <= y + w - 1; j++)
        {
            dd[i][j] = 0;
        }
    }
}

void Try(int i)
{
    if (i == n + 1)
    {
        cout << 1 << endl;
        exit(0);
        return;
    }

    for (int i = 1; i <= H - h[i] + 1; i++)
    {
        for (int j = 1; j <= W - w[i] + 1; j++)
        {
            if (can_fit(i, j, H, W))
            {
                place(i, j, h[i], w[i]);
                Try(i + 1);
                remov(i, j, h[i], w[i]);
            }
        }
    }
    swap(h[i], w[i]);
    for (int i = 1; i <= H - h[i] + 1; i++)
    {
        for (int j = 1; j <= W - w[i] + 1; j++)
        {
            if (can_fit(i, j, H, W))
            {
                place(i, j, h[i], w[i]);
                Try(i + 1);
                remov(i, j, h[i], w[i]);
            }
        }
    }
    swap(h[i], w[i]);
}

int main()
{
    cin >> H >> W;
    cin >> n;
    // int totalarea = 0;
    // int area = H * W;
    for (int i = 1; i <= n; i++)
    {
        cin >> h[i] >> w[i];
        // totalarea += h[i] * w[i];
    }

    // if (totalarea != area)
    // {
    //     cout << 0;
    //     return 0;
    // } else {
    //     Try(1);
    //     cout << 0;
    //     return 0;
    // }

    Try(1);
    cout << 0;
    return 0;
}