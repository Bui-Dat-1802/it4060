#include <bits/stdc++.h>
using namespace std;

int res = 2e9;
bool dd[50][50];
int load[50], clients[50];
int best_path, cmin;
int n, K, Q;
bool visited[50];
int x[50];
int c[50][50], d[50];

void try_route(int i, int k, int path)
{
    if (i == clients[k] + 1)
    {
        best_path = min(best_path, path + c[x[clients[k]]][0]);
    }
    else
    {
        for (int j = 1; j <= n; j++)
            if (dd[k][j] && !visited[j])
            {
                if (path + cmin * (clients[k] - i + 1) >= best_path)
                    continue;

                visited[j] = 1;
                x[i] = j;
                try_route(i + 1, k, path + c[x[i - 1]][j]);
                visited[j] = 0;
            }
    }
}
void try_truck(int i) // tư duy ngược , với mỗi điểm i thử gán cho nó 1 xe j nào đó (j<=K)
{
    if (i == n + 1)
    {
        // đã phân k xe cho n khách hàng
        int sum = 0;
        // với mỗi xe i t làm riêng 1 tuyến đường ngắn nhất cho nó để giao cho các khách hàng của nó (chính là bài cbus nhưng làm k lần)
        for (int i = 1; i <= K; i++)
            if (clients[i])
            {
                x[0] = 0;
                best_path = 1e9;
                cmin = 1e9;
                for (int j1 = 0; j1 <= n; j1++)
                    for (int j2 = 0; j2 <= n; j2++)
                        if (dd[i][j1] && dd[i][j2] && j1 != j2)
                            cmin = min(cmin, c[j1][j2]);

                try_route(1, i, 0); // tìm tuyến đường ngắn nhất cho xe i

                sum += best_path; // cộng lại vào tổng
            }
        res = min(res, sum);
    }
    else
    {
        for (int j = 1; j <= K; j++)
        {
            if (load[j] + d[i] > Q)
                continue; // xe j quá tải trọng

            load[j] += d[i]; // tải trọng xe j
            dd[j][i] = 1;    // biến đánh dấu xe j được phân giao hàng cho khách i
            clients[j]++;    // số lượng khách mà xe j phải trả hàng

            try_truck(i + 1);

            // thử xong xe j thoát ra phải trả lại khách hàng i
            load[j] -= d[i];
            clients[j]--;
            dd[j][i] = 0;
        }
    }
}
main()
{
    cin >> n >> K >> Q;
    for (int i = 1; i <= n; i++)
        cin >> d[i];
    for (int i = 0; i <= n; i++)
        for (int j = 0; j <= n; j++)
            cin >> c[i][j];

    for (int i = 1; i <= K; i++)
        dd[i][0] = 1;
    try_truck(1);
    cout << res;
}