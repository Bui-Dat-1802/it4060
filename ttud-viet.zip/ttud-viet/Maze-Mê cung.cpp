//C++  m� cung  
#include <bits/stdc++.h>

using namespace std;

struct Node {
    int x, y, dist;
};

int n, m, r, c;
vector<vector<int>> maze;
vector<vector<bool>> visited;
int dx[] = {-1, 1, 0, 0};
int dy[] = {0, 0, -1, 1};

bool isValid(int x, int y) {
    return (x >= 0 && x < n && y >= 0 && y < m && maze[x][y] == 0 && !visited[x][y]);
}

int bfs(int startX, int startY) {
    queue<Node> q;
    q.push({startX, startY, 1});
    visited[startX][startY] = true;
    
    while (!q.empty()) {
        Node node = q.front();
        q.pop();
        int x = node.x;
        int y = node.y;
        int dist = node.dist;
        if (x == 0 || x == n-1 || y == 0 || y == m-1) {
            return dist;
        }

        for (int i = 0; i < 4; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];
            
            if (isValid(newX, newY)) {
                visited[newX][newY] = true;
                q.push({newX, newY, dist + 1});
            }
        }
    }
    
    return -1; 
}

int main() {
    cin >> n >> m >> r >> c;
    r--; c--; 
    maze.resize(n, vector<int>(m));
    visited.resize(n, vector<bool>(m, false));
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            cin >> maze[i][j];
        }
    }
    
    if (maze[r][c] == 1) {
        cout << -1 << endl; 
    } else {
        cout << bfs(r, c) << endl;
    }
    
    return 0;
}

