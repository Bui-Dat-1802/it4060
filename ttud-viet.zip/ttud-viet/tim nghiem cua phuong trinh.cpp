//C++ dem nghiem phuong trinh tuyen tinh so nguyen a1x1+a2x2+....=M 
#include <iostream>
#include <vector>
 

using namespace std;

int Count(int a, int b, vector<int>& c) {
    int sum = 0;
    for (int i = 0; i < a; i++) {
        sum += c[i];
    }
    b-=sum; 
    if (b < 0) return 0; 
    vector<int> d(b + 1, 0);
    d[0] = 1; 
    for (int i : c) {
        for (int m = i; m <= b; m++) {
            d[m] += d[m - i];
        }
    }

    return d[b];
}

int main() {
    int n, M;
    cin >> n >> M;
    vector<int> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    int res = Count(n, M, a);
    cout << res << endl;
    return 0;
}

