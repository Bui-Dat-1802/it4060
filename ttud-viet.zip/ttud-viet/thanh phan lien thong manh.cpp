//C++ do thi lien thong manh 
#include <bits/stdc++.h>
using namespace std;

const int MAX = 100005;
vector<int> adj[MAX], rev_adj[MAX];
bool visited[MAX];
stack<int> s;

void dfs1(int u) {
    visited[u] = true;
    for (int v : adj[u]) {
        if (!visited[v]) dfs1(v);
    }
    s.push(u);
}

void dfs2(int u) {
    visited[u] = true;
    for (int v : rev_adj[u]) {
        if (!visited[v]) dfs2(v);
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        rev_adj[v].push_back(u);
    }
    for (int i = 1; i <= n; ++i) visited[i] = false;
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) dfs1(i);
    }
    for (int i = 1; i <= n; ++i) visited[i] = false;
    int scc_count = 0;
    while (!s.empty()) {
        int u = s.top(); s.pop();
        if (!visited[u]) {
            dfs2(u);
            ++scc_count;
        }
    }
    cout << scc_count << endl;
    return 0;
}

